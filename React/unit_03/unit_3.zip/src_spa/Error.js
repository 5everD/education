function Error() {
  return (
    <div>
      <h1>Error_404</h1>
    </div>
  );
}

export default Error;