import React from 'react';
import In from './In';
import Out from './Out'
import './App.css';

export default function App() {
  return (
    <div className="App">
      <In/>
      <Out/>
    </div>
  );
}
