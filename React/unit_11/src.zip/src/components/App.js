import './App.css';
import AddUser from "../containers/AddUser";
import UserList from "../containers/UserList";

export default function App() {
  return (
    <div>
      <AddUser/>
      <UserList/>
    </div>
  );
}
