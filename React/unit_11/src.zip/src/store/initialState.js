const initialState = {
  user: [
    {
      passport: '1234 567890',
      name: 'John',
      age: 36,
    }
  ]
}

export default initialState;