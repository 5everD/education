function About() {
    return (
        <div className="container">
            <p className="lorem">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam corporis error fuga fugit in inventore iste, minus neque nihil nisi nobis odit placeat quam quasi quibusdam, quos ratione tempore voluptatem?</p>
        </div>
    );
}

export default About;