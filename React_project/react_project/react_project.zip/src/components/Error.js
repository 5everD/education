function Error() {
    return (
        <div>
            ОШИБКА!
        </div>
    );
}

export default Error;